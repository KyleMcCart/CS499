const storyForm = document.getElementById("storyForm");
const titleInput = document.getElementById("title");
const descriptionInput = document.getElementById("description");
const criteriaInput = document.getElementById("criteria");
const sprintInput = document.getElementById("sprint");
const priorityInput = document.getElementById("priority");
const errorMessage = document.getElementById("errorMessage");
const submitBtn = document.getElementById("submitBtn");

const todoList = document.getElementById("todo");
const inProgressList = document.getElementById("inProgress");
const doneList = document.getElementById("done");

const progressText = document.getElementById("progressText");
const progressFill = document.getElementById("progressFill");

let stories = JSON.parse(localStorage.getItem("stories")) || [];
let editId = null;

storyForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const title = titleInput.value.trim();
  const description = descriptionInput.value.trim();
  const criteria = criteriaInput.value.trim();
  const sprint = sprintInput.value.trim();
  const priority = priorityInput.value;

  if (!title || !description || !criteria || !sprint) {
    errorMessage.textContent = "Please complete all fields before adding a story.";
    return;
  }

  errorMessage.textContent = "";

  if (editId) {
    stories = stories.map(function (story) {
      if (story.id === editId) {
        return {
          ...story,
          title,
          description,
          criteria,
          sprint,
          priority
        };
      }
      return story;
    });

    editId = null;
    submitBtn.textContent = "Add Story";
  } else {
    const newStory = {
      id: Date.now(),
      title,
      description,
      criteria,
      sprint,
      priority,
      status: "todo"
    };

    stories.push(newStory);
  }

  saveStories();
  clearForm();
  renderStories();
});

function renderStories() {
  todoList.innerHTML = "";
  inProgressList.innerHTML = "";
  doneList.innerHTML = "";

  stories.forEach(function (story) {
    const card = document.createElement("div");
    card.className = `task-card priority-${story.priority.toLowerCase()}`;

    card.innerHTML = `
      <h3>${story.title}</h3>
      <p><strong>User Story:</strong> ${story.description}</p>
      <p><strong>Acceptance Criteria:</strong> ${story.criteria}</p>
      <p><strong>Sprint:</strong> ${story.sprint}</p>
      <p><strong>Priority:</strong> ${story.priority}</p>

      <div class="card-actions">
        <select onchange="updateStatus(${story.id}, this.value)">
          <option value="todo" ${story.status === "todo" ? "selected" : ""}>To Do</option>
          <option value="inProgress" ${story.status === "inProgress" ? "selected" : ""}>In Progress</option>
          <option value="done" ${story.status === "done" ? "selected" : ""}>Done</option>
        </select>

        <button class="edit-btn" onclick="editStory(${story.id})">Edit</button>
        <button class="delete-btn" onclick="deleteStory(${story.id})">Delete</button>
      </div>
    `;

    if (story.status === "todo") {
      todoList.appendChild(card);
    } else if (story.status === "inProgress") {
      inProgressList.appendChild(card);
    } else {
      doneList.appendChild(card);
    }
  });

  updateProgress();
}

function updateStatus(id, newStatus) {
  stories = stories.map(function (story) {
    if (story.id === id) {
      return {
        ...story,
        status: newStatus
      };
    }
    return story;
  });

  saveStories();
  renderStories();
}

function editStory(id) {
  const storyToEdit = stories.find(function (story) {
    return story.id === id;
  });

  if (!storyToEdit) {
    return;
  }

  titleInput.value = storyToEdit.title;
  descriptionInput.value = storyToEdit.description;
  criteriaInput.value = storyToEdit.criteria;
  sprintInput.value = storyToEdit.sprint;
  priorityInput.value = storyToEdit.priority;

  editId = id;
  submitBtn.textContent = "Update Story";
  window.scrollTo(0, 0);
}

function deleteStory(id) {
  stories = stories.filter(function (story) {
    return story.id !== id;
  });

  saveStories();
  renderStories();
}

function updateProgress() {
  const totalStories = stories.length;
  const completedStories = stories.filter(function (story) {
    return story.status === "done";
  }).length;

  if (totalStories === 0) {
    progressText.textContent = "No stories added yet.";
    progressFill.style.width = "0%";
    return;
  }

  const percentage = Math.round((completedStories / totalStories) * 100);

  progressText.textContent = `Sprint Progress: ${completedStories} of ${totalStories} stories complete (${percentage}%).`;
  progressFill.style.width = `${percentage}%`;
}

function saveStories() {
  localStorage.setItem("stories", JSON.stringify(stories));
}

function clearForm() {
  titleInput.value = "";
  descriptionInput.value = "";
  criteriaInput.value = "";
  sprintInput.value = "";
  priorityInput.value = "Low";
}

renderStories();