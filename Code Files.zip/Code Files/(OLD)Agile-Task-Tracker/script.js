let stories = JSON.parse(localStorage.getItem("stories")) || [];

const form = document.getElementById("storyForm");
const errorMessage = document.getElementById("errorMessage");

form.addEventListener("submit", function (event) {
  event.preventDefault();

  const title = document.getElementById("title").value.trim();
  const description = document.getElementById("description").value.trim();
  const criteria = document.getElementById("criteria").value.trim();
  const sprint = document.getElementById("sprint").value.trim();
  const priority = document.getElementById("priority").value;

  if (title === "" || description === "" || criteria === "") {
    errorMessage.textContent = "Please complete the title, user story, and acceptance criteria.";
    return;
  }

  const newStory = {
    id: Date.now(),
    title: title,
    description: description,
    criteria: criteria,
    sprint: sprint || "Unassigned",
    priority: priority,
    status: "todo"
  };

  stories.push(newStory);
  saveStories();
  renderStories();

  form.reset();
  errorMessage.textContent = "";
});

function saveStories() {
  localStorage.setItem("stories", JSON.stringify(stories));
}

function renderStories() {
  document.getElementById("todo").innerHTML = "";
  document.getElementById("inProgress").innerHTML = "";
  document.getElementById("testing").innerHTML = "";
  document.getElementById("done").innerHTML = "";

  stories.forEach(function (story) {
    const card = document.createElement("div");
    card.className = "task-card";

    card.innerHTML = `
      <h3>${story.title}</h3>
      <p><strong>User Story:</strong> ${story.description}</p>
      <p><strong>Acceptance Criteria:</strong> ${story.criteria}</p>
      <p><strong>Sprint:</strong> ${story.sprint}</p>
      <p><strong>Priority:</strong> ${story.priority}</p>
      <div class="task-buttons">
        <button onclick="changeStatus(${story.id}, 'todo')">To Do</button>
        <button onclick="changeStatus(${story.id}, 'inProgress')">In Progress</button>
        <button onclick="changeStatus(${story.id}, 'testing')">Testing</button>
        <button onclick="changeStatus(${story.id}, 'done')">Done</button>
        <button class="delete-btn" onclick="deleteStory(${story.id})">Delete</button>
      </div>
    `;

    document.getElementById(story.status).appendChild(card);
  });
}

function changeStatus(id, newStatus) {
  stories = stories.map(function (story) {
    if (story.id === id) {
      story.status = newStatus;
    }
    return story;
  });

  saveStories();
  renderStories();
}

function deleteStory(id) {
  stories = stories.filter(function (story) {
    return story.id !== id;
  });

  saveStories();
  renderStories();
}

renderStories();