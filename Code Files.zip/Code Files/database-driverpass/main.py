import sqlite3
from datetime import datetime

DB_NAME = "driverpass.db"


def connect_db():
    conn = sqlite3.connect(DB_NAME)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            package_type TEXT NOT NULL CHECK(package_type IN ('Basic', 'Standard', 'Premium'))
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS instructors (
            instructor_id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS vehicles (
            vehicle_id INTEGER PRIMARY KEY AUTOINCREMENT,
            make TEXT NOT NULL,
            model TEXT NOT NULL,
            license_plate TEXT UNIQUE NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS lessons (
            lesson_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            instructor_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            lesson_date TEXT NOT NULL,
            lesson_time TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('Scheduled', 'Completed', 'Cancelled')),
            FOREIGN KEY (student_id) REFERENCES students(student_id),
            FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id),
            FOREIGN KEY (vehicle_id) REFERENCES vehicles(vehicle_id),
            UNIQUE(instructor_id, lesson_date, lesson_time),
            UNIQUE(student_id, lesson_date, lesson_time),
            UNIQUE(vehicle_id, lesson_date, lesson_time)
        )
    """)

    conn.commit()
    conn.close()


def add_sample_data():
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO students (first_name, last_name, email, package_type)
            VALUES 
            ('Maria', 'Lopez', 'maria@email.com', 'Premium'),
            ('Jordan', 'Miller', 'jordan@email.com', 'Basic'),
            ('Ava', 'Johnson', 'ava@email.com', 'Standard')
        """)

        cursor.execute("""
            INSERT INTO instructors (first_name, last_name, email)
            VALUES 
            ('Alex', 'Carter', 'alex@driverpass.com'),
            ('Taylor', 'Smith', 'taylor@driverpass.com')
        """)

        cursor.execute("""
            INSERT INTO vehicles (make, model, license_plate)
            VALUES
            ('Toyota', 'Corolla', 'DP101'),
            ('Honda', 'Civic', 'DP202')
        """)

        conn.commit()
        print("Sample data added successfully.")

    except sqlite3.IntegrityError:
        print("Sample data already exists.")

    conn.close()


def is_valid_id(value):
    return value.isdigit() and int(value) > 0


def is_valid_date(date_text):
    try:
        datetime.strptime(date_text, "%Y-%m-%d")
        return True
    except ValueError:
        return False


def is_valid_time(time_text):
    try:
        datetime.strptime(time_text, "%I:%M %p")
        return True
    except ValueError:
        return False


def record_exists(table_name, id_column, record_id):
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute(f"SELECT 1 FROM {table_name} WHERE {id_column} = ?", (record_id,))
    result = cursor.fetchone()

    conn.close()
    return result is not None


def add_student():
    conn = connect_db()
    cursor = conn.cursor()

    first_name = input("Enter student first name: ").strip()
    last_name = input("Enter student last name: ").strip()
    email = input("Enter student email: ").strip()
    package_type = input("Enter package type, Basic, Standard, or Premium: ").strip()

    if not first_name or not last_name or not email or not package_type:
        print("Error: All fields are required.")
        conn.close()
        return

    if package_type not in ["Basic", "Standard", "Premium"]:
        print("Error: Package type must be Basic, Standard, or Premium.")
        conn.close()
        return

    try:
        cursor.execute("""
            INSERT INTO students (first_name, last_name, email, package_type)
            VALUES (?, ?, ?, ?)
        """, (first_name, last_name, email, package_type))

        conn.commit()
        print("Student added successfully.")

    except sqlite3.IntegrityError:
        print("Error: A student with this email already exists.")

    conn.close()


def add_instructor():
    conn = connect_db()
    cursor = conn.cursor()

    first_name = input("Enter instructor first name: ").strip()
    last_name = input("Enter instructor last name: ").strip()
    email = input("Enter instructor email: ").strip()

    if not first_name or not last_name or not email:
        print("Error: All fields are required.")
        conn.close()
        return

    try:
        cursor.execute("""
            INSERT INTO instructors (first_name, last_name, email)
            VALUES (?, ?, ?)
        """, (first_name, last_name, email))

        conn.commit()
        print("Instructor added successfully.")

    except sqlite3.IntegrityError:
        print("Error: An instructor with this email already exists.")

    conn.close()


def add_vehicle():
    conn = connect_db()
    cursor = conn.cursor()

    make = input("Enter vehicle make: ").strip()
    model = input("Enter vehicle model: ").strip()
    license_plate = input("Enter license plate: ").strip()

    if not make or not model or not license_plate:
        print("Error: All fields are required.")
        conn.close()
        return

    try:
        cursor.execute("""
            INSERT INTO vehicles (make, model, license_plate)
            VALUES (?, ?, ?)
        """, (make, model, license_plate))

        conn.commit()
        print("Vehicle added successfully.")

    except sqlite3.IntegrityError:
        print("Error: A vehicle with this license plate already exists.")

    conn.close()


def schedule_lesson():
    conn = connect_db()
    cursor = conn.cursor()

    student_id = input("Enter student ID: ").strip()
    instructor_id = input("Enter instructor ID: ").strip()
    vehicle_id = input("Enter vehicle ID: ").strip()
    lesson_date = input("Enter lesson date, example 2026-05-15: ").strip()
    lesson_time = input("Enter lesson time, example 09:00 AM: ").strip()

    if not is_valid_id(student_id) or not is_valid_id(instructor_id) or not is_valid_id(vehicle_id):
        print("Error: Student ID, instructor ID, and vehicle ID must be valid numbers.")
        conn.close()
        return

    if not is_valid_date(lesson_date):
        print("Error: Date must be in YYYY-MM-DD format.")
        conn.close()
        return

    if not is_valid_time(lesson_time):
        print("Error: Time must be in HH:MM AM/PM format, example 09:00 AM.")
        conn.close()
        return

    if not record_exists("students", "student_id", student_id):
        print("Error: Student does not exist.")
        conn.close()
        return

    if not record_exists("instructors", "instructor_id", instructor_id):
        print("Error: Instructor does not exist.")
        conn.close()
        return

    if not record_exists("vehicles", "vehicle_id", vehicle_id):
        print("Error: Vehicle does not exist.")
        conn.close()
        return

    try:
        cursor.execute("""
            INSERT INTO lessons (student_id, instructor_id, vehicle_id, lesson_date, lesson_time, status)
            VALUES (?, ?, ?, ?, ?, 'Scheduled')
        """, (student_id, instructor_id, vehicle_id, lesson_date, lesson_time))

        conn.commit()
        print("Lesson scheduled successfully.")

    except sqlite3.IntegrityError:
        print("Error: The student, instructor, or vehicle is already booked at that date and time.")

    conn.close()


def view_students():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT student_id, first_name, last_name, email, package_type
        FROM students
        ORDER BY last_name
    """)

    students = cursor.fetchall()

    print("\nStudents:")
    if not students:
        print("No students found.")
    else:
        for student in students:
            print(f"ID: {student[0]} | Name: {student[1]} {student[2]} | Email: {student[3]} | Package: {student[4]}")

    conn.close()


def view_instructors():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT instructor_id, first_name, last_name, email
        FROM instructors
        ORDER BY last_name
    """)

    instructors = cursor.fetchall()

    print("\nInstructors:")
    if not instructors:
        print("No instructors found.")
    else:
        for instructor in instructors:
            print(f"ID: {instructor[0]} | Name: {instructor[1]} {instructor[2]} | Email: {instructor[3]}")

    conn.close()


def view_vehicles():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT vehicle_id, make, model, license_plate
        FROM vehicles
        ORDER BY vehicle_id
    """)

    vehicles = cursor.fetchall()

    print("\nVehicles:")
    if not vehicles:
        print("No vehicles found.")
    else:
        for vehicle in vehicles:
            print(f"ID: {vehicle[0]} | Vehicle: {vehicle[1]} {vehicle[2]} | Plate: {vehicle[3]}")

    conn.close()


def view_all_lessons():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            lessons.lesson_id,
            students.first_name || ' ' || students.last_name AS student_name,
            instructors.first_name || ' ' || instructors.last_name AS instructor_name,
            vehicles.make || ' ' || vehicles.model AS vehicle_name,
            vehicles.license_plate,
            lessons.lesson_date,
            lessons.lesson_time,
            lessons.status
        FROM lessons
        JOIN students ON lessons.student_id = students.student_id
        JOIN instructors ON lessons.instructor_id = instructors.instructor_id
        JOIN vehicles ON lessons.vehicle_id = vehicles.vehicle_id
        ORDER BY lessons.lesson_date, lessons.lesson_time
    """)

    lessons = cursor.fetchall()

    print("\nAll Lessons:")
    if not lessons:
        print("No lessons found.")
    else:
        for lesson in lessons:
            print(
                f"ID: {lesson[0]} | Student: {lesson[1]} | Instructor: {lesson[2]} | "
                f"Vehicle: {lesson[3]} ({lesson[4]}) | Date: {lesson[5]} | "
                f"Time: {lesson[6]} | Status: {lesson[7]}"
            )

    conn.close()


def search_lessons_by_student():
    conn = connect_db()
    cursor = conn.cursor()

    student_id = input("Enter student ID: ").strip()

    if not is_valid_id(student_id):
        print("Error: Student ID must be a valid number.")
        conn.close()
        return

    cursor.execute("""
        SELECT 
            students.first_name || ' ' || students.last_name AS student_name,
            instructors.first_name || ' ' || instructors.last_name AS instructor_name,
            vehicles.make || ' ' || vehicles.model AS vehicle_name,
            lessons.lesson_date,
            lessons.lesson_time,
            lessons.status
        FROM lessons
        JOIN students ON lessons.student_id = students.student_id
        JOIN instructors ON lessons.instructor_id = instructors.instructor_id
        JOIN vehicles ON lessons.vehicle_id = vehicles.vehicle_id
        WHERE students.student_id = ?
        ORDER BY lessons.lesson_date, lessons.lesson_time
    """, (student_id,))

    results = cursor.fetchall()

    print("\nStudent Lessons:")
    if not results:
        print("No lessons found for this student.")
    else:
        for lesson in results:
            print(
                f"Student: {lesson[0]} | Instructor: {lesson[1]} | Vehicle: {lesson[2]} | "
                f"Date: {lesson[3]} | Time: {lesson[4]} | Status: {lesson[5]}"
            )

    conn.close()


def search_lessons_by_instructor():
    conn = connect_db()
    cursor = conn.cursor()

    instructor_id = input("Enter instructor ID: ").strip()

    if not is_valid_id(instructor_id):
        print("Error: Instructor ID must be a valid number.")
        conn.close()
        return

    cursor.execute("""
        SELECT 
            instructors.first_name || ' ' || instructors.last_name AS instructor_name,
            students.first_name || ' ' || students.last_name AS student_name,
            vehicles.make || ' ' || vehicles.model AS vehicle_name,
            lessons.lesson_date,
            lessons.lesson_time,
            lessons.status
        FROM lessons
        JOIN students ON lessons.student_id = students.student_id
        JOIN instructors ON lessons.instructor_id = instructors.instructor_id
        JOIN vehicles ON lessons.vehicle_id = vehicles.vehicle_id
        WHERE instructors.instructor_id = ?
        ORDER BY lessons.lesson_date, lessons.lesson_time
    """, (instructor_id,))

    results = cursor.fetchall()

    print("\nInstructor Lessons:")
    if not results:
        print("No lessons found for this instructor.")
    else:
        for lesson in results:
            print(
                f"Instructor: {lesson[0]} | Student: {lesson[1]} | Vehicle: {lesson[2]} | "
                f"Date: {lesson[3]} | Time: {lesson[4]} | Status: {lesson[5]}"
            )

    conn.close()


def update_lesson_status():
    conn = connect_db()
    cursor = conn.cursor()

    lesson_id = input("Enter lesson ID: ").strip()
    new_status = input("Enter new status, Scheduled, Completed, or Cancelled: ").strip()

    if not is_valid_id(lesson_id):
        print("Error: Lesson ID must be a valid number.")
        conn.close()
        return

    if new_status not in ["Scheduled", "Completed", "Cancelled"]:
        print("Invalid status. Use Scheduled, Completed, or Cancelled.")
        conn.close()
        return

    cursor.execute("""
        UPDATE lessons
        SET status = ?
        WHERE lesson_id = ?
    """, (new_status, lesson_id))

    conn.commit()

    if cursor.rowcount == 0:
        print("Lesson not found.")
    else:
        print("Lesson status updated successfully.")

    conn.close()


def delete_lesson():
    conn = connect_db()
    cursor = conn.cursor()

    lesson_id = input("Enter lesson ID to delete: ").strip()

    if not is_valid_id(lesson_id):
        print("Error: Lesson ID must be a valid number.")
        conn.close()
        return

    cursor.execute("DELETE FROM lessons WHERE lesson_id = ?", (lesson_id,))
    conn.commit()

    if cursor.rowcount == 0:
        print("Lesson not found.")
    else:
        print("Lesson deleted successfully.")

    conn.close()


def student_progress_report():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            students.student_id,
            students.first_name || ' ' || students.last_name AS student_name,
            students.package_type,
            COUNT(lessons.lesson_id) AS total_lessons,
            SUM(CASE WHEN lessons.status = 'Completed' THEN 1 ELSE 0 END) AS completed_lessons,
            SUM(CASE WHEN lessons.status = 'Scheduled' THEN 1 ELSE 0 END) AS scheduled_lessons,
            SUM(CASE WHEN lessons.status = 'Cancelled' THEN 1 ELSE 0 END) AS cancelled_lessons
        FROM students
        LEFT JOIN lessons ON students.student_id = lessons.student_id
        GROUP BY students.student_id
        ORDER BY students.last_name
    """)

    reports = cursor.fetchall()

    print("\nStudent Progress Report:")
    if not reports:
        print("No student records found.")
    else:
        for report in reports:
            print(
                f"ID: {report[0]} | Student: {report[1]} | Package: {report[2]} | "
                f"Total Lessons: {report[3]} | Completed: {report[4]} | "
                f"Scheduled: {report[5]} | Cancelled: {report[6]}"
            )

    conn.close()


def main():
    create_tables()
    add_sample_data()

    while True:
        print("\nDriverPass Database Menu")
        print("1. Add Student")
        print("2. Add Instructor")
        print("3. Add Vehicle")
        print("4. Schedule Lesson")
        print("5. View Students")
        print("6. View Instructors")
        print("7. View Vehicles")
        print("8. View All Lessons")
        print("9. Search Lessons by Student")
        print("10. Search Lessons by Instructor")
        print("11. Update Lesson Status")
        print("12. Delete Lesson")
        print("13. Student Progress Report")
        print("14. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            add_student()

        elif choice == "2":
            add_instructor()

        elif choice == "3":
            add_vehicle()

        elif choice == "4":
            schedule_lesson()

        elif choice == "5":
            view_students()

        elif choice == "6":
            view_instructors()

        elif choice == "7":
            view_vehicles()

        elif choice == "8":
            view_all_lessons()

        elif choice == "9":
            search_lessons_by_student()

        elif choice == "10":
            search_lessons_by_instructor()

        elif choice == "11":
            update_lesson_status()

        elif choice == "12":
            delete_lesson()

        elif choice == "13":
            student_progress_report()

        elif choice == "14":
            print("Goodbye.")
            break

        else:
            print("Invalid option. Please try again.")


if __name__ == "__main__":
    main()