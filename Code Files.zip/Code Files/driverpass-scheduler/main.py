from datetime import datetime

students = {}
instructors = {}
appointments = []


def add_student(student_id, name):
    students[student_id] = {
        "name": name,
        "appointments": []
    }


def add_instructor(instructor_id, name):
    instructors[instructor_id] = {
        "name": name,
        "appointments": []
    }


def is_valid_datetime(date_time):
    try:
        datetime.strptime(date_time, "%Y-%m-%d %I:%M %p")
        return True
    except ValueError:
        return False


def is_instructor_available(instructor_id, date_time):
    for appointment in appointments:
        if (
            appointment["instructor_id"] == instructor_id
            and appointment["date_time"] == date_time
            and appointment["status"] != "Cancelled"
        ):
            return False
    return True


def is_student_available(student_id, date_time):
    for appointment in appointments:
        if (
            appointment["student_id"] == student_id
            and appointment["date_time"] == date_time
            and appointment["status"] != "Cancelled"
        ):
            return False
    return True


def book_appointment(student_id, instructor_id, date_time):
    student_id = student_id.strip().upper()
    instructor_id = instructor_id.strip().upper()
    date_time = date_time.strip()

    if student_id not in students:
        print("Student not found.")
        return

    if instructor_id not in instructors:
        print("Instructor not found.")
        return

    if not is_valid_datetime(date_time):
        print("Invalid date and time format. Use example: 2026-05-15 09:00 AM")
        return

    if not is_student_available(student_id, date_time):
        print("This student already has an appointment at that time.")
        return

    if not is_instructor_available(instructor_id, date_time):
        print("This instructor is already booked at that time.")
        return

    appointment = {
        "appointment_id": len(appointments) + 1,
        "student_id": student_id,
        "student_name": students[student_id]["name"],
        "instructor_id": instructor_id,
        "instructor_name": instructors[instructor_id]["name"],
        "date_time": date_time,
        "status": "Scheduled"
    }

    appointments.append(appointment)
    students[student_id]["appointments"].append(appointment)
    instructors[instructor_id]["appointments"].append(appointment)

    print("Appointment booked successfully.")


def search_appointments_by_student(student_id):
    student_id = student_id.strip().upper()

    if student_id not in students:
        print("Student not found.")
        return

    print(f"\nAppointments for {students[student_id]['name']}:")

    student_appointments = students[student_id]["appointments"]

    if not student_appointments:
        print("No appointments found.")
        return

    for appointment in student_appointments:
        print(
            f"ID: {appointment['appointment_id']} | "
            f"{appointment['date_time']} with {appointment['instructor_name']} | "
            f"Status: {appointment['status']}"
        )


def search_appointments_by_instructor(instructor_id):
    instructor_id = instructor_id.strip().upper()

    if instructor_id not in instructors:
        print("Instructor not found.")
        return

    print(f"\nAppointments for {instructors[instructor_id]['name']}:")

    instructor_appointments = instructors[instructor_id]["appointments"]

    if not instructor_appointments:
        print("No appointments found.")
        return

    for appointment in instructor_appointments:
        print(
            f"ID: {appointment['appointment_id']} | "
            f"{appointment['date_time']} with {appointment['student_name']} | "
            f"Status: {appointment['status']}"
        )


def show_all_appointments():
    print("\nAll Booked Appointments:")

    if not appointments:
        print("No appointments booked.")
        return

    for appointment in appointments:
        print(
            f"ID: {appointment['appointment_id']} | "
            f"{appointment['student_name']} with "
            f"{appointment['instructor_name']} at "
            f"{appointment['date_time']} | "
            f"Status: {appointment['status']}"
        )


def show_available_times(instructor_id, possible_times):
    instructor_id = instructor_id.strip().upper()

    if instructor_id not in instructors:
        print("Instructor not found.")
        return

    print(f"\nAvailable times for {instructors[instructor_id]['name']}:")

    available_found = False

    for time in possible_times:
        if is_instructor_available(instructor_id, time):
            print(f"- {time}")
            available_found = True

    if not available_found:
        print("No available times found.")


def update_appointment_status(appointment_id, new_status):
    valid_statuses = ["Scheduled", "Completed", "Cancelled"]

    if not appointment_id.isdigit():
        print("Appointment ID must be a number.")
        return

    appointment_id = int(appointment_id)
    new_status = new_status.strip().title()

    if new_status not in valid_statuses:
        print("Invalid status. Use Scheduled, Completed, or Cancelled.")
        return

    for appointment in appointments:
        if appointment["appointment_id"] == appointment_id:
            appointment["status"] = new_status
            print("Appointment status updated successfully.")
            return

    print("Appointment not found.")


def cancel_appointment(appointment_id):
    if not appointment_id.isdigit():
        print("Appointment ID must be a number.")
        return

    appointment_id = int(appointment_id)

    for appointment in appointments:
        if appointment["appointment_id"] == appointment_id:
            appointment["status"] = "Cancelled"
            print("Appointment cancelled successfully.")
            return

    print("Appointment not found.")


def student_progress_report():
    print("\nStudent Progress Report:")

    for student_id, student in students.items():
        total = len(student["appointments"])
        completed = 0
        scheduled = 0
        cancelled = 0

        for appointment in student["appointments"]:
            if appointment["status"] == "Completed":
                completed += 1
            elif appointment["status"] == "Scheduled":
                scheduled += 1
            elif appointment["status"] == "Cancelled":
                cancelled += 1

        print(
            f"{student_id} | {student['name']} | "
            f"Total: {total} | Completed: {completed} | "
            f"Scheduled: {scheduled} | Cancelled: {cancelled}"
        )


def show_students():
    print("\nStudents:")

    for student_id, student in students.items():
        print(f"{student_id} | {student['name']}")


def show_instructors():
    print("\nInstructors:")

    for instructor_id, instructor in instructors.items():
        print(f"{instructor_id} | {instructor['name']}")


def main():
    add_student("S001", "Maria Lopez")
    add_student("S002", "Jordan Miller")
    add_student("S003", "Ava Johnson")

    add_instructor("I001", "Alex Carter")
    add_instructor("I002", "Taylor Smith")
    add_instructor("I003", "Morgan Lee")

    possible_times = [
        "2026-05-15 09:00 AM",
        "2026-05-15 10:00 AM",
        "2026-05-15 11:00 AM",
        "2026-05-15 01:00 PM",
        "2026-05-16 09:00 AM",
        "2026-05-16 10:00 AM",
        "2026-05-16 11:00 AM",
        "2026-05-16 01:00 PM"
    ]

    while True:
        print("\nDriverPass Scheduler")
        print("1. Book Appointment")
        print("2. View All Appointments")
        print("3. Search Appointments by Student")
        print("4. Search Appointments by Instructor")
        print("5. Show Available Instructor Times")
        print("6. Update Appointment Status")
        print("7. Cancel Appointment")
        print("8. Student Progress Report")
        print("9. View Students")
        print("10. View Instructors")
        print("11. Exit")

        choice = input("Choose an option: ").strip()

        if choice == "1":
            show_students()
            show_instructors()
            student_id = input("Enter student ID: ")
            instructor_id = input("Enter instructor ID: ")
            date_time = input("Enter date and time, example 2026-05-15 09:00 AM: ")
            book_appointment(student_id, instructor_id, date_time)

        elif choice == "2":
            show_all_appointments()

        elif choice == "3":
            student_id = input("Enter student ID: ")
            search_appointments_by_student(student_id)

        elif choice == "4":
            instructor_id = input("Enter instructor ID: ")
            search_appointments_by_instructor(instructor_id)

        elif choice == "5":
            instructor_id = input("Enter instructor ID: ")
            show_available_times(instructor_id, possible_times)

        elif choice == "6":
            appointment_id = input("Enter appointment ID: ")
            new_status = input("Enter new status, Scheduled, Completed, or Cancelled: ")
            update_appointment_status(appointment_id, new_status)

        elif choice == "7":
            appointment_id = input("Enter appointment ID to cancel: ")
            cancel_appointment(appointment_id)

        elif choice == "8":
            student_progress_report()

        elif choice == "9":
            show_students()

        elif choice == "10":
            show_instructors()

        elif choice == "11":
            print("Goodbye.")
            break

        else:
            print("Invalid option. Please try again.")


main()