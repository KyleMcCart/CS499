import sqlite3

DB_NAME = "driverpass.db"


def connect_db():
    return sqlite3.connect(DB_NAME)


def create_tables():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS students (
            student_id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            package_type TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS instructors (
            instructor_id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS lessons (
            lesson_id INTEGER PRIMARY KEY AUTOINCREMENT,
            student_id INTEGER NOT NULL,
            instructor_id INTEGER NOT NULL,
            lesson_date TEXT NOT NULL,
            lesson_time TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('Scheduled', 'Completed', 'Cancelled')),
            FOREIGN KEY (student_id) REFERENCES students(student_id),
            FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id),
            UNIQUE(instructor_id, lesson_date, lesson_time)
        )
    """)

    conn.commit()
    conn.close()


def add_sample_data():
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO students (first_name, last_name, email, package_type)
            VALUES 
            ('Maria', 'Lopez', 'maria@email.com', 'Premium'),
            ('Jordan', 'Miller', 'jordan@email.com', 'Basic')
        """)

        cursor.execute("""
            INSERT INTO instructors (first_name, last_name, email)
            VALUES 
            ('Alex', 'Carter', 'alex@driverpass.com'),
            ('Taylor', 'Smith', 'taylor@driverpass.com')
        """)

        conn.commit()
        print("Sample data added successfully.")

    except sqlite3.IntegrityError:
        print("Sample data already exists.")

    conn.close()


def schedule_lesson(student_id, instructor_id, lesson_date, lesson_time):
    conn = connect_db()
    cursor = conn.cursor()

    try:
        cursor.execute("""
            INSERT INTO lessons (student_id, instructor_id, lesson_date, lesson_time, status)
            VALUES (?, ?, ?, ?, 'Scheduled')
        """, (student_id, instructor_id, lesson_date, lesson_time))

        conn.commit()
        print("Lesson scheduled successfully.")

    except sqlite3.IntegrityError:
        print("Error: This instructor is already booked at that date and time.")

    conn.close()


def view_all_lessons():
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            lessons.lesson_id,
            students.first_name || ' ' || students.last_name AS student_name,
            instructors.first_name || ' ' || instructors.last_name AS instructor_name,
            lessons.lesson_date,
            lessons.lesson_time,
            lessons.status
        FROM lessons
        JOIN students ON lessons.student_id = students.student_id
        JOIN instructors ON lessons.instructor_id = instructors.instructor_id
        ORDER BY lessons.lesson_date, lessons.lesson_time
    """)

    lessons = cursor.fetchall()

    print("\nAll Lessons:")
    if not lessons:
        print("No lessons found.")
    else:
        for lesson in lessons:
            print(f"ID: {lesson[0]} | Student: {lesson[1]} | Instructor: {lesson[2]} | Date: {lesson[3]} | Time: {lesson[4]} | Status: {lesson[5]}")

    conn.close()


def search_lessons_by_student(student_id):
    conn = connect_db()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT 
            students.first_name || ' ' || students.last_name AS student_name,
            instructors.first_name || ' ' || instructors.last_name AS instructor_name,
            lessons.lesson_date,
            lessons.lesson_time,
            lessons.status
        FROM lessons
        JOIN students ON lessons.student_id = students.student_id
        JOIN instructors ON lessons.instructor_id = instructors.instructor_id
        WHERE students.student_id = ?
    """, (student_id,))

    results = cursor.fetchall()

    print("\nStudent Lessons:")
    if not results:
        print("No lessons found for this student.")
    else:
        for lesson in results:
            print(f"Student: {lesson[0]} | Instructor: {lesson[1]} | Date: {lesson[2]} | Time: {lesson[3]} | Status: {lesson[4]}")

    conn.close()


def update_lesson_status(lesson_id, new_status):
    conn = connect_db()
    cursor = conn.cursor()

    if new_status not in ["Scheduled", "Completed", "Cancelled"]:
        print("Invalid status. Use Scheduled, Completed, or Cancelled.")
        conn.close()
        return

    cursor.execute("""
        UPDATE lessons
        SET status = ?
        WHERE lesson_id = ?
    """, (new_status, lesson_id))

    conn.commit()

    if cursor.rowcount == 0:
        print("Lesson not found.")
    else:
        print("Lesson status updated successfully.")

    conn.close()


def main():
    create_tables()
    add_sample_data()

    while True:
        print("\nDriverPass Database Menu")
        print("1. Schedule Lesson")
        print("2. View All Lessons")
        print("3. Search Lessons by Student")
        print("4. Update Lesson Status")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            student_id = input("Enter student ID: ")
            instructor_id = input("Enter instructor ID: ")
            lesson_date = input("Enter lesson date, example 2026-05-15: ")
            lesson_time = input("Enter lesson time, example 09:00 AM: ")
            schedule_lesson(student_id, instructor_id, lesson_date, lesson_time)

        elif choice == "2":
            view_all_lessons()

        elif choice == "3":
            student_id = input("Enter student ID: ")
            search_lessons_by_student(student_id)

        elif choice == "4":
            lesson_id = input("Enter lesson ID: ")
            new_status = input("Enter new status: Scheduled, Completed, or Cancelled: ")
            update_lesson_status(lesson_id, new_status)

        elif choice == "5":
            print("Goodbye.")
            break

        else:
            print("Invalid option. Please try again.")


main()