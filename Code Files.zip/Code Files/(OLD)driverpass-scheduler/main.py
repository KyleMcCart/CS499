from datetime import datetime

students = {}
instructors = {}
appointments = []


def add_student(student_id, name):
    students[student_id] = {
        "name": name,
        "appointments": []
    }


def add_instructor(instructor_id, name):
    instructors[instructor_id] = {
        "name": name,
        "appointments": []
    }


def is_time_available(instructor_id, date_time):
    for appointment in appointments:
        if appointment["instructor_id"] == instructor_id and appointment["date_time"] == date_time:
            return False
    return True


def book_appointment(student_id, instructor_id, date_time):
    if student_id not in students:
        print("Student not found.")
        return

    if instructor_id not in instructors:
        print("Instructor not found.")
        return

    if not is_time_available(instructor_id, date_time):
        print("This instructor is already booked at that time.")
        return

    appointment = {
        "student_id": student_id,
        "student_name": students[student_id]["name"],
        "instructor_id": instructor_id,
        "instructor_name": instructors[instructor_id]["name"],
        "date_time": date_time
    }

    appointments.append(appointment)
    students[student_id]["appointments"].append(appointment)
    instructors[instructor_id]["appointments"].append(appointment)

    print("Appointment booked successfully.")


def search_appointments_by_student(student_id):
    if student_id not in students:
        print("Student not found.")
        return

    print(f"\nAppointments for {students[student_id]['name']}:")
    for appointment in students[student_id]["appointments"]:
        print(f"- {appointment['date_time']} with {appointment['instructor_name']}")


def show_all_appointments():
    print("\nAll Booked Appointments:")
    if not appointments:
        print("No appointments booked.")
        return

    for appointment in appointments:
        print(
            f"{appointment['student_name']} with "
            f"{appointment['instructor_name']} at "
            f"{appointment['date_time']}"
        )


def show_available_times(instructor_id, possible_times):
    if instructor_id not in instructors:
        print("Instructor not found.")
        return

    print(f"\nAvailable times for {instructors[instructor_id]['name']}:")
    for time in possible_times:
        if is_time_available(instructor_id, time):
            print(f"- {time}")


def main():
    add_student("S001", "Maria Lopez")
    add_student("S002", "Jordan Miller")

    add_instructor("I001", "Alex Carter")
    add_instructor("I002", "Taylor Smith")

    possible_times = [
        "2026-05-15 09:00 AM",
        "2026-05-15 10:00 AM",
        "2026-05-15 11:00 AM",
        "2026-05-15 01:00 PM"
    ]

    while True:
        print("\nDriverPass Scheduler")
        print("1. Book Appointment")
        print("2. View All Appointments")
        print("3. Search Appointments by Student")
        print("4. Show Available Instructor Times")
        print("5. Exit")

        choice = input("Choose an option: ")

        if choice == "1":
            student_id = input("Enter student ID: ")
            instructor_id = input("Enter instructor ID: ")
            date_time = input("Enter date and time, example 2026-05-15 09:00 AM: ")
            book_appointment(student_id, instructor_id, date_time)

        elif choice == "2":
            show_all_appointments()

        elif choice == "3":
            student_id = input("Enter student ID: ")
            search_appointments_by_student(student_id)

        elif choice == "4":
            instructor_id = input("Enter instructor ID: ")
            show_available_times(instructor_id, possible_times)

        elif choice == "5":
            print("Goodbye.")
            break

        else:
            print("Invalid option. Please try again.")


main()